<?php

namespace App\Entity;

use ApiPlatform\Metadata\ApiResource;
use App\Repository\ProfessionalRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use App\Entity\JobTitle;
use App\Entity\Specialty;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Entity\ProService;

#[ORM\Entity(repositoryClass: ProfessionalRepository::class)]
#[ApiResource]
class Professional
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    // =========================================================================
    // RELATIONS TECHNIQUES
    // =========================================================================

    #[ORM\OneToOne(inversedBy: 'professional', cascade: ['persist', 'remove'])]
    #[ORM\JoinColumn(nullable: false)]
    private ?User $user = null;

    // =========================================================================
    // 1. IDENTITÉ PUBLIQUE (Source 3.3)
    // =========================================================================

    #[ORM\Column(length: 255)]
    private ?string $firstName = null;

    #[ORM\Column(length: 255)]
    private ?string $lastName = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $avatarPath = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $biography = null;

    #[ORM\ManyToOne(targetEntity: JobTitle::class)]
    #[ORM\JoinColumn(nullable: false)] // Un pro DOIT avoir un métier
    private ?JobTitle $jobTitle = null;

    /**
     * @var Collection<int, Specialty>
     */
    #[ORM\ManyToMany(targetEntity: Specialty::class)]
    private Collection $specialties;

    // =========================================================================
    // 2. LOCALISATION (Source 3.3 - Localisation)
    // =========================================================================

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $city = null;

    #[ORM\Column(length: 20, nullable: true)]
    private ?string $zipCode = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $departmentName = null;

    #[ORM\Column(length: 5, nullable: true)]
    private ?string $departmentCode = null;

    // =========================================================================
    // 3. IDENTITÉ LÉGALE B2B (Source 3.3 - Identité Légale)
    // =========================================================================

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $companyName = null;

    #[ORM\Column(length: 50, nullable: true)]
    private ?string $siretNumber = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $billingAddress = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $stripeAccountId = null;

    #[ORM\Column(type: 'boolean')]
    private ?bool $isStripeVerified = false;

    // =========================================================================
    // 4. PARAMÈTRES MAGASIN (Source 3.3 - Paramètres "Magasin")
    // =========================================================================

    #[ORM\Column]
    private ?int $standardDelayDays = 7;

    #[ORM\Column(type: 'boolean')]
    private ?bool $isExpressEnabled = false;

    #[ORM\Column(type: Types::FLOAT, nullable: true)]
    private ?float $expressPremiumPercent = null;

    #[ORM\Column(nullable: true)]
    private ?int $maxActiveOrders = null;

    #[ORM\Column(length: 50)]
    private ?string $status = 'ACTIVE'; // Enum: ACTIVE, UNAVAILABLE, SUSPENDED

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $unavailableUntil = null;

    #[ORM\OneToMany(mappedBy: 'professional', targetEntity: ProService::class, cascade: ['persist', 'remove'])]
    private Collection $proServices;

    public function __construct()
    {
        $this->specialties = new ArrayCollection();
        $this->proServices = new ArrayCollection();
    }

    // =========================================================================
    // GETTERS & SETTERS
    // =========================================================================

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(User $user): static
    {
        $this->user = $user;
        return $this;
    }

    public function getFirstName(): ?string
    {
        return $this->firstName;
    }

    public function setFirstName(string $firstName): static
    {
        $this->firstName = $firstName;
        return $this;
    }

    public function getLastName(): ?string
    {
        return $this->lastName;
    }

    public function setLastName(string $lastName): static
    {
        $this->lastName = $lastName;
        return $this;
    }

    public function getAvatarPath(): ?string
    {
        return $this->avatarPath;
    }

    public function setAvatarPath(?string $avatarPath): static
    {
        $this->avatarPath = $avatarPath;
        return $this;
    }

    public function getBiography(): ?string
    {
        return $this->biography;
    }

    public function setBiography(?string $biography): static
    {
        $this->biography = $biography;
        return $this;
    }

    public function getCity(): ?string
    {
        return $this->city;
    }

    public function setCity(?string $city): static
    {
        $this->city = $city;
        return $this;
    }

    public function getZipCode(): ?string
    {
        return $this->zipCode;
    }

    public function setZipCode(?string $zipCode): static
    {
        $this->zipCode = $zipCode;
        return $this;
    }

    public function getDepartmentName(): ?string
    {
        return $this->departmentName;
    }

    public function setDepartmentName(?string $departmentName): static
    {
        $this->departmentName = $departmentName;
        return $this;
    }

    public function getDepartmentCode(): ?string
    {
        return $this->departmentCode;
    }

    public function setDepartmentCode(?string $departmentCode): static
    {
        $this->departmentCode = $departmentCode;
        return $this;
    }

    public function getCompanyName(): ?string
    {
        return $this->companyName;
    }

    public function setCompanyName(?string $companyName): static
    {
        $this->companyName = $companyName;
        return $this;
    }

    public function getSiretNumber(): ?string
    {
        return $this->siretNumber;
    }

    public function setSiretNumber(?string $siretNumber): static
    {
        $this->siretNumber = $siretNumber;
        return $this;
    }

    public function getBillingAddress(): ?string
    {
        return $this->billingAddress;
    }

    public function setBillingAddress(?string $billingAddress): static
    {
        $this->billingAddress = $billingAddress;
        return $this;
    }

    public function getStripeAccountId(): ?string
    {
        return $this->stripeAccountId;
    }

    public function setStripeAccountId(?string $stripeAccountId): static
    {
        $this->stripeAccountId = $stripeAccountId;
        return $this;
    }

    public function isStripeVerified(): ?bool
    {
        return $this->isStripeVerified;
    }

    public function setIsStripeVerified(bool $isStripeVerified): static
    {
        $this->isStripeVerified = $isStripeVerified;
        return $this;
    }

    public function getStandardDelayDays(): ?int
    {
        return $this->standardDelayDays;
    }

    public function setStandardDelayDays(int $standardDelayDays): static
    {
        $this->standardDelayDays = $standardDelayDays;
        return $this;
    }

    public function isExpressEnabled(): ?bool
    {
        return $this->isExpressEnabled;
    }

    public function setIsExpressEnabled(bool $isExpressEnabled): static
    {
        $this->isExpressEnabled = $isExpressEnabled;
        return $this;
    }

    public function getExpressPremiumPercent(): ?float
    {
        return $this->expressPremiumPercent;
    }

    public function setExpressPremiumPercent(?float $expressPremiumPercent): static
    {
        $this->expressPremiumPercent = $expressPremiumPercent;
        return $this;
    }

    public function getMaxActiveOrders(): ?int
    {
        return $this->maxActiveOrders;
    }

    public function setMaxActiveOrders(?int $maxActiveOrders): static
    {
        $this->maxActiveOrders = $maxActiveOrders;
        return $this;
    }

    public function getStatus(): ?string
    {
        return $this->status;
    }

    public function setStatus(string $status): static
    {
        $this->status = $status;
        return $this;
    }

    public function getUnavailableUntil(): ?\DateTimeInterface
    {
        return $this->unavailableUntil;
    }

    public function setUnavailableUntil(?\DateTimeInterface $unavailableUntil): static
    {
        $this->unavailableUntil = $unavailableUntil;
        return $this;
    }

    public function getJobTitle(): ?JobTitle
    {
        return $this->jobTitle;
    }

    public function setJobTitle(?JobTitle $jobTitle): static
    {
        $this->jobTitle = $jobTitle;
        return $this;
    }

    /**
     * @return Collection<int, Specialty>
     */
    public function getSpecialties(): Collection
    {
        return $this->specialties;
    }

    public function addSpecialty(Specialty $specialty): static
    {
        if (!$this->specialties->contains($specialty)) {
            $this->specialties->add($specialty);
        }
        return $this;
    }

    public function removeSpecialty(Specialty $specialty): static
    {
        $this->specialties->removeElement($specialty);
        return $this;
    }

    /**
     * @return Collection<int, ProService>
     */
    public function getProServices(): Collection
    {
        return $this->proServices;
    }

    public function addProService(ProService $proService): static
    {
        if (!$this->proServices->contains($proService)) {
            $this->proServices->add($proService);
            $proService->setProfessional($this);
        }

        return $this;
    }

    public function removeProService(ProService $proService): static
    {
        if ($this->proServices->removeElement($proService)) {
            // set the owning side to null (unless already changed)
            if ($proService->getProfessional() === $this) {
                $proService->setProfessional(null);
            }
        }

        return $this;
    }
}